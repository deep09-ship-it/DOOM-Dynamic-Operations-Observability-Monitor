# 💀 DOOM : A Telemetry-Driven Cloud Health Platform
### **D.O.O.M.** — *Deep Operational Object Monitor*
#### Course: CM51207 (Cloud Computing) | Government Polytechnic, Pune

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![Flask](https://img.shields.io/badge/Framework-Flask-green.svg)](https://flask.palletsprojects.com/)
[![Docker](https://img.shields.io/badge/Container-Docker-cyan.svg)](https://docker.com)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> *"If your server goes down, your pet dies. Keep it alive."* 💀🐾

---

## 🎯 What is DOOM?

**DOOM** (**D**eep **O**perational **O**bject **M**onitor) is a bio-inspired, gamified cloud infrastructure monitoring platform that bridges server telemetry (CPU, RAM, Disk, Uptime, Latency, Security Ports) with an interactive virtual creature whose life and evolution stage are directly tied to real cloud server performance.

---

## ✨ Key Features

- **🎮 Biometric Cloud Mapping**: Translates raw `psutil` system metrics into 8 living pet stats (Health, Hunger, Energy, Happiness, Defense, Intelligence, Wealth, XP).
- **🧬 5 Evolution Stages**: Pet evolves from `CloudEgg 🥚` → `ByteBaby 🐣` → `NimbusKid 🐥` → `CumuloBird 🐦` → `CloudDragon 🐉` as XP and server stability increase.
- **🍕 Storage Cleanup ("Feed")**: Purges temporary files and docker log bloat, reducing disk usage and feeding the pet (CO4).
- **⚡ Resource Tuning ("Play")**: Optimizes CPU thread allocations and idle processes (CO3).
- **🛡️ Security Shield ("Heal")**: Audits open ports (SSH, MySQL, HTTP), hardens firewall rules, and patches vulnerabilities (CO5).
- **📖 Auto-Generated Pet Diary**: Logs human interactions and server events in a cute auto-generated pet journal.
- **📋 Full Syllabus CO Alignment**: Embedded interactive CO1–CO6 mapping table directly in the dashboard.

---

## 📊 Course Outcome (CO1–CO6) Coverage Matrix

| CO Code | Course Outcome Title | DOOM Platform Implementation |
|---------|----------------------|------------------------------|
| **CO1** | Cloud Computing Fundamentals | Models cloud VM virtualization, resource elasticity (CPU/RAM scaling), and multi-tenancy state within the pet's living environment. |
| **CO2** | Cloud Service Models (IaaS, PaaS, SaaS) | Runs on IaaS (VM/Docker), utilizes PaaS (Serverless/Flask API endpoints), and serves an interactive SaaS dashboard. |
| **CO3** | Service & Resource Management | Real-time `psutil` CPU/RAM load monitoring, pet health tied to SLA uptime (99.9%), and resource optimization via 'Play' action. |
| **CO4** | Cloud Storage Management | Storage Cleanup module ('Feed' action) scans temp/log bloat, enforces lifecycle cleanup, and persists pet state JSON. |
| **CO5** | Cloud Security Measures | Automated security scanner audits open ports, firewall status, and weak permissions. 'Heal' action applies automated patches. |
| **CO6** | Open Source & Commercial Clouds | Containerized with Docker & Docker Compose for OpenStack deployment, with GCP Cloud Run configuration provided. |

---

## 🏗️ Technical Architecture

```mermaid
graph TD
    subgraph "☁️ Cloud VM / Docker Container (IaaS)"
        A[Flask Web Server / API] --> B[psutil Telemetry Collector]
        A --> C[Security Scanner & Firewall Audit]
        A --> D[Storage Cleanup Module]
        B --> E[Pet Biometric Calculator]
        C --> E
        D --> E
    end

    subgraph "💾 Persistence Layer (CO4)"
        F[pet_state.json]
        G[journal_logs.json]
        E --> F
        A --> G
    end

    subgraph "🖥️ Interactive SaaS Dashboard (Frontend)"
        H[Retro Cyberpunk Canvas UI]
        I[Live Stat Meters & Gauges]
        J[Action Toolbar - Feed / Play / Heal]
        H <--> A
        I <--> A
        J <--> A
    end
```

---

## 🚀 Quick Start & Installation

### Option 1: Run Locally (Python 3.11+)

1. Navigate to project root:
   ```bash
   cd "D:\All MIrcroproject\CC"
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Launch the platform:
   ```bash
   python app.py
   ```

4. Open your browser at:
   ```
   http://localhost:5000
   ```

---

### Option 2: Run via Docker / OpenStack (CO6)

1. Build and run using Docker Compose:
   ```bash
   docker-compose up --build
   ```

2. Access the platform at `http://localhost:5000`.

---

## 👥 Team & Credits

- **Course:** CM51207 — Cloud Computing (Elective)
- **Scheme:** '120 - NEP' Scheme
- **Institution:** Government Polytechnic, Pune
