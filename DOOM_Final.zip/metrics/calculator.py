def calculate_pet_stats(raw_metrics, sec_report, base_xp=0):
    """
    Translates raw cloud performance telemetry and security audit scores
    into 8 Pet Stat indicators.
    """
    cpu = raw_metrics.get("cpu_percent", 20.0)
    disk = raw_metrics.get("disk_percent", 40.0)
    ram = raw_metrics.get("ram_percent", 50.0)
    latency = raw_metrics.get("latency_ms", 25.0)
    uptime_hrs = raw_metrics.get("uptime_seconds", 3600) / 3600.0
    sec_score = sec_report.get("security_score", 100)

    # 1. Health (HP): Max 100, drops if CPU/RAM is extreme (>85%) or security is weak
    health_penalty = 0
    if cpu > 85.0:
        health_penalty += (cpu - 85.0) * 1.5
    if ram > 90.0:
        health_penalty += (ram - 90.0) * 1.0
    if sec_score < 70:
        health_penalty += (70 - sec_score) * 0.8
    
    health = max(0.0, min(100.0, 100.0 - health_penalty))

    # 2. Hunger: Tied to Disk Usage (100% disk = 100% hunger / starving)
    hunger = max(0.0, min(100.0, disk))

    # 3. Energy: Inversely proportional to CPU load
    energy = max(0.0, min(100.0, 100.0 - cpu))

    # 4. Happiness: High if latency is low (<50ms) and health is good
    latency_score = max(0.0, min(100.0, 100.0 - (latency * 1.2)))
    happiness = max(0.0, min(100.0, (health * 0.5) + (latency_score * 0.5)))

    # 5. Defense: Directly equals Security Score
    defense = float(sec_score)

    # 6. Intelligence: Based on configured services & uptime stability
    intelligence = max(10.0, min(100.0, 50.0 + (uptime_hrs * 2.0)))

    # 7. Wealth: Cost efficiency index (stays under free tier quotas)
    wealth = max(20.0, min(100.0, 100.0 - (ram * 0.4)))

    return {
        "health": round(health, 1),
        "hunger": round(hunger, 1),
        "energy": round(energy, 1),
        "happiness": round(happiness, 1),
        "defense": round(defense, 1),
        "intelligence": round(intelligence, 1),
        "wealth": round(wealth, 1),
        "xp": base_xp
    }
