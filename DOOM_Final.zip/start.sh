#!/bin/bash
# ============================================================
# DOOM Platform - One-Click Startup Script
# Run this once on a fresh Google Cloud VM and you're done!
# ============================================================

echo ""
echo "🔥 DOOM Platform Setup Starting..."
echo "============================================================"

# Step 1: Install pip without sudo
echo "[1/3] Installing pip..."
curl -sS https://bootstrap.pypa.io/get-pip.py | python3 - --break-system-packages --quiet
echo "      ✅ pip installed."

# Step 2: Install Python requirements in user space
echo "[2/3] Installing Python dependencies..."
python3 -m pip install --user -r requirements.txt --break-system-packages --ignore-installed --quiet
echo "      ✅ Dependencies installed."

# Step 3: Kill any old server and start fresh
echo "[3/3] Starting DOOM server on port 5000..."
pkill -f app.py 2>/dev/null
sleep 1
nohup python3 app.py > output.log 2>&1 &

sleep 3

# Check if it actually started
if grep -q "DOOM Platform" output.log; then
    echo ""
    echo "============================================================"
    echo "✅ SUCCESS! DOOM Platform is LIVE!"
    echo ""
    echo "👉 Open your browser and go to:"
    echo "   http://$(curl -s ifconfig.me):5000"
    echo "============================================================"
else
    echo ""
    echo "❌ Something went wrong. Here's the error:"
    cat output.log
fi
