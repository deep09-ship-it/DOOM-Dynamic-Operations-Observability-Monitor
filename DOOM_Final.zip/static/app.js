document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const petSprite = document.getElementById('petSprite');
    const petName = document.getElementById('petName');
    const petStageTitle = document.getElementById('petStageTitle');
    const petStageBadge = document.getElementById('petStageBadge');
    const petMood = document.getElementById('petMood');
    
    const xpText = document.getElementById('xpText');
    const xpProgress = document.getElementById('xpProgress');
    const btnEvolve = document.getElementById('btnEvolve');

    // Stat bars
    const barHealth = document.getElementById('barHealth');
    const valHealth = document.getElementById('valHealth');
    const barHunger = document.getElementById('barHunger');
    const valHunger = document.getElementById('valHunger');
    const barEnergy = document.getElementById('barEnergy');
    const valEnergy = document.getElementById('valEnergy');
    const barHappiness = document.getElementById('barHappiness');
    const valHappiness = document.getElementById('valHappiness');
    const barDefense = document.getElementById('barDefense');
    const valDefense = document.getElementById('valDefense');
    const barIntelligence = document.getElementById('barIntelligence');
    const valIntelligence = document.getElementById('valIntelligence');

    // Telemetry Gauges
    const metricCpu = document.getElementById('metricCpu');
    const metricRam = document.getElementById('metricRam');
    const metricDisk = document.getElementById('metricDisk');
    const metricLatency = document.getElementById('metricLatency');
    const metricNet = document.getElementById('metricNet');
    const metricPorts = document.getElementById('metricPorts');
    const uptimeBadge = document.getElementById('uptimeBadge');

    // Action Buttons
    const btnFeed = document.getElementById('btnFeed');
    const btnPlay = document.getElementById('btnPlay');
    const btnHeal = document.getElementById('btnHeal');

    // Tab buttons & panes
    const tabContainer = document.getElementById('tabContainer');
    const tabBtns = tabContainer.querySelectorAll('button');
    const tabPanes = ['tab-journal', 'tab-events', 'tab-audit', 'tab-co'];

    let isPolling = true;

    // --- Tab Switching Handler (Shadcn style) ---
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Reset all buttons
            tabBtns.forEach(b => {
                b.setAttribute('data-state', 'inactive');
                b.className = "inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-muted hover:text-muted-foreground text-muted-foreground";
            });
            
            // Set active button
            btn.setAttribute('data-state', 'active');
            btn.className = "inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm bg-background text-foreground shadow-sm";

            // Hide all panes
            tabPanes.forEach(p => {
                document.getElementById(p).classList.add('hidden');
                document.getElementById(p).classList.remove('block');
            });

            // Show active pane
            const target = btn.getAttribute('data-tab');
            document.getElementById(target).classList.remove('hidden');
            document.getElementById(target).classList.add('block');
        });
    });

    // --- Fetch Main Status ---
    async function fetchPetStatus() {
        try {
            const res = await fetch('/api/pet/status');
            if (!res.ok) return;
            const data = await res.json();
            renderDashboard(data);
        } catch (err) {
            console.error("Error fetching pet status:", err);
        }
    }

    function renderDashboard(data) {
        const { stage, stats, cloud_metrics, security_report, pet_mood, next_stage_available } = data;

        // 1. Stage Info
        petSprite.textContent = stage.emoji || '🥚';
        petStageTitle.textContent = stage.title || 'Stage 0';
        petStageBadge.textContent = `Stage ${stage.stage}`;
        petMood.textContent = pet_mood.text;
        
        // 2. XP & Evolution
        xpText.textContent = `${stats.xp} XP (Target: ${stage.stage < 4 ? getTargetXP(stage.stage) : 'MAX'})`;
        const pctXP = Math.min(100, Math.round((stats.xp / (getTargetXP(stage.stage) || 1000)) * 100));
        xpProgress.style.width = `${pctXP}%`;

        btnEvolve.disabled = !next_stage_available;
        if (next_stage_available) {
            btnEvolve.innerHTML = `<i data-lucide="zap" class="mr-2 h-4 w-4"></i>Evolve Now!`;
            lucide.createIcons();
        }

        // 3. Stats Bars
        updateBar(barHealth, valHealth, stats.health);
        updateBar(barHunger, valHunger, stats.hunger);
        updateBar(barEnergy, valEnergy, stats.energy);
        updateBar(barHappiness, valHappiness, stats.happiness);
        updateBar(barDefense, valDefense, stats.defense);
        updateBar(barIntelligence, valIntelligence, stats.intelligence);

        // 4. Raw Cloud Telemetry
        metricCpu.textContent = `${cloud_metrics.cpu_percent}%`;
        metricRam.textContent = `${cloud_metrics.ram_percent}%`;
        metricDisk.textContent = `${cloud_metrics.disk_percent}%`;
        metricLatency.textContent = `${cloud_metrics.latency_ms}ms`;

        metricNet.textContent = `${cloud_metrics.bytes_sent_mb} MB / ${cloud_metrics.bytes_recv_mb} MB`;

        const openPortsStr = security_report.monitored_ports
            .filter(p => p.status !== "SECURE")
            .map(p => `${p.port}(${p.service})`)
            .join(', ');
        metricPorts.textContent = openPortsStr || 'All Secure';

        uptimeBadge.textContent = formatUptime(cloud_metrics.uptime_seconds);
    }

    function updateBar(barElem, valElem, value) {
        if (!barElem || !valElem) return;
        const valNum = Math.max(0, Math.min(100, value));
        barElem.style.width = `${valNum}%`;
        valElem.textContent = `${valNum}%`;
    }

    function getTargetXP(currStage) {
        const targets = [50, 150, 350, 700, 1000];
        return targets[currStage + 1] || 1000;
    }

    function formatUptime(seconds) {
        const hrs = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }

    function pad(n) {
        return n < 10 ? '0' + n : n;
    }

    // --- Action Handlers ---
    async function triggerAction(actionName) {
        try {
            const res = await fetch('/api/pet/action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: actionName })
            });
            const data = await res.json();
            if (data.error) {
                alert(data.error);
                return;
            }
            fetchPetStatus();
            fetchJournal();
            fetchEvents();
            fetchAudit();
        } catch (err) {
            console.error(`Error performing action ${actionName}:`, err);
        }
    }

    btnFeed.addEventListener('click', () => triggerAction('feed'));
    btnPlay.addEventListener('click', () => triggerAction('play'));
    btnHeal.addEventListener('click', () => triggerAction('heal'));
    btnEvolve.addEventListener('click', () => triggerAction('evolve'));

    // --- Fetch Tab Data ---
    async function fetchJournal() {
        try {
            const res = await fetch('/api/pet/journal');
            const data = await res.json();
            const container = document.getElementById('journalList');
            if (!container) return;

            container.innerHTML = data.entries.map(e => `
                <div class="flex items-start gap-4 rounded-lg border border-border p-4 bg-muted/20">
                    <div class="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                        <i data-lucide="terminal" class="h-4 w-4 text-primary"></i>
                    </div>
                    <div class="grid gap-1">
                        <div class="flex items-center gap-2">
                            <span class="text-sm font-medium leading-none">${e.tag}</span>
                            <span class="text-xs text-muted-foreground">${e.date}</span>
                        </div>
                        <p class="text-sm text-muted-foreground">${e.content}</p>
                    </div>
                </div>
            `).join('');
            lucide.createIcons();
        } catch (err) {}
    }

    async function fetchEvents() {
        try {
            const res = await fetch('/api/pet/events');
            const data = await res.json();
            const container = document.getElementById('eventsList');
            if (!container) return;

            container.innerHTML = data.events.map(ev => `
                <div class="flex items-start gap-4 rounded-lg border border-border p-4 bg-muted/20">
                    <div class="flex h-8 w-8 items-center justify-center rounded-full bg-secondary">
                        <i data-lucide="zap" class="h-4 w-4 text-primary"></i>
                    </div>
                    <div class="grid gap-1">
                        <div class="flex items-center gap-2">
                            <span class="text-sm font-medium leading-none">${ev.title}</span>
                            <span class="text-xs text-muted-foreground">${ev.timestamp}</span>
                        </div>
                        <p class="text-sm text-muted-foreground">${ev.desc}</p>
                    </div>
                </div>
            `).join('');
            lucide.createIcons();
        } catch (err) {}
    }

    async function fetchAudit() {
        try {
            const res = await fetch('/api/audit');
            const data = await res.json();
            const container = document.getElementById('auditList');
            if (!container || !data.audit || data.audit.length === 0) return;

            container.innerHTML = data.audit.map(log => `
                <div class="border-l-2 border-emerald-500/50 pl-3 py-1">
                    <span class="text-emerald-400">[${log.timestamp}]</span>
                    <span class="text-blue-400 font-bold ml-2">${log.action}</span><br>
                    <span class="text-muted-foreground">$ ${log.cmd}</span><br>
                    <span class="text-foreground">${log.status}</span>
                </div>
            `).join('');
        } catch (err) {}
    }

    async function fetchCOMapping() {
        try {
            const res = await fetch('/api/pet/co-mapping');
            const data = await res.json();
            const tbody = document.getElementById('coTableBody');
            if (!tbody) return;

            tbody.innerHTML = data.course_outcomes.map(item => `
                <tr class="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <td class="p-4 align-middle font-medium">${item.co}</td>
                    <td class="p-4 align-middle">${item.title}</td>
                    <td class="p-4 align-middle text-muted-foreground">${item.implementation}</td>
                </tr>
            `).join('');
        } catch (err) {}
    }

    // Initial Load
    fetchPetStatus();
    fetchJournal();
    fetchEvents();
    fetchAudit();
    fetchCOMapping();

    setInterval(() => {
        if (isPolling) fetchPetStatus();
    }, 3000);
});
