import time

class JournalManager:
    def __init__(self):
        self.entries = [
            {
                "date": time.strftime("%Y-%m-%d %H:%M"),
                "tag": "SETUP",
                "content": "Dear Diary, I was just deployed on this Cloud VM! My human configured Flask, psutil, and security monitoring. I feel alive! 🥚"
            },
            {
                "date": time.strftime("%Y-%m-%d %H:%M"),
                "tag": "SECURITY",
                "content": "A port scanner attempted to probe port 22 and 8080. My human ran security hardening and firewall defense. Defense score is 100%! 🛡️"
            }
        ]

    def add_entry(self, category, content):
        entry = {
            "date": time.strftime("%Y-%m-%d %H:%M"),
            "tag": category.upper(),
            "content": f"Dear Diary: {content}"
        }
        self.entries.insert(0, entry)

    def get_recent_entries(self):
        return self.entries[:10]
