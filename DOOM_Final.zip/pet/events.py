import random

EVENT_POOL = [
    {"title": "🦠 DDoS Attack Repelled", "desc": "Firewall rules blocked 1,200 malicious packets. Defense held strong!"},
    {"title": "🌊 Storage Overflow Warning", "desc": "Temporary log files increased disk usage by 12%. Feed pet to clean bloat."},
    {"title": "⚡ CPU Spike Detected", "desc": "A background thread consumed 88% CPU load. Play & optimize to restore balance."},
    {"title": "🎁 Cloud Free-Tier Bonus", "desc": "GCP billing staying 100% within free limits. Wealth +15%!"},
    {"title": "🌈 High Uptime Streak", "desc": "Cloud VM achieved 99.9% uptime SLA. Health & happiness restored!"}
]

def get_random_cloud_event():
    return random.choice(EVENT_POOL)
