import os
import json
import time
from metrics.calculator import calculate_pet_stats

DATA_FILE = os.path.join(os.path.dirname(__file__), 'pet_state.json')

EVOLUTION_STAGES = [
    {
        "stage": 0,
        "name": "CloudEgg",
        "title": "Stage 0: Unhatched Egg",
        "emoji": "🥚",
        "min_xp": 0,
        "min_health": 0,
        "desc": "A glowing egg sitting safely inside a cloud server rack."
    },
    {
        "stage": 1,
        "name": "ByteBaby",
        "title": "Stage 1: Byte Baby",
        "emoji": "🐣",
        "min_xp": 50,
        "min_health": 60,
        "desc": "A cute digital baby blob that reacts to system load."
    },
    {
        "stage": 2,
        "name": "NimbusKid",
        "title": "Stage 2: Nimbus Kid",
        "emoji": "🐥",
        "min_xp": 150,
        "min_health": 70,
        "desc": "An energetic cloud kid with tiny digital wings."
    },
    {
        "stage": 3,
        "name": "CumuloBird",
        "title": "Stage 3: Cumulo Bird",
        "emoji": "🐦",
        "min_xp": 350,
        "min_health": 80,
        "desc": "A majestic cloud bird with multi-zone load balancing power."
    },
    {
        "stage": 4,
        "name": "CloudDragon",
        "title": "Stage 4: Cloud Dragon",
        "emoji": "🐉",
        "min_xp": 700,
        "min_health": 90,
        "desc": "A legendary Cloud Dragon sitting on an enterprise cloud throne!"
    }
]

class PetEngine:
    def __init__(self):
        self.state = self._load_state()
        self.events_history = self.state.get('events_history', [])

    def _load_state(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, 'r') as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            "name": "DOOM-Pet",
            "xp": 0,
            "stage": 0,
            "total_feeds": 0,
            "total_plays": 0,
            "total_heals": 0,
            "created_at": time.time(),
            "events_history": []
        }

    def _save_state(self):
        try:
            self.state['events_history'] = self.events_history[-20:] # Keep last 20 events
            with open(DATA_FILE, 'w') as f:
                json.dump(self.state, f, indent=2)
        except Exception:
            pass

    def update_state(self, raw_metrics, sec_report):
        stats = calculate_pet_stats(raw_metrics, sec_report, base_xp=self.state['xp'])
        
        # Check evolution stage
        curr_stage_idx = self.state['stage']
        curr_stage_info = EVOLUTION_STAGES[curr_stage_idx]
        
        # Auto-check if next stage condition met
        next_stage_available = False
        if curr_stage_idx < len(EVOLUTION_STAGES) - 1:
            next_req = EVOLUTION_STAGES[curr_stage_idx + 1]
            if self.state['xp'] >= next_req['min_xp'] and stats['health'] >= next_req['min_health']:
                next_stage_available = True

        status = {
            "name": self.state['name'],
            "stage": curr_stage_info,
            "next_stage_available": next_stage_available,
            "stats": stats,
            "cloud_metrics": raw_metrics,
            "security_report": sec_report,
            "totals": {
                "feeds": self.state['total_feeds'],
                "plays": self.state['total_plays'],
                "heals": self.state['total_heals']
            },
            "pet_mood": self._get_mood(stats)
        }
        return status

    def _get_mood(self, stats):
        if stats['health'] < 30:
            return {"text": "Critical Condition 🚨", "color": "#ff3344"}
        elif stats['hunger'] > 85:
            return {"text": "Starving for Storage 🍔", "color": "#ffaa00"}
        elif stats['energy'] < 25:
            return {"text": "CPU Exhausted ⚡", "color": "#ffaa00"}
        elif stats['defense'] < 60:
            return {"text": "Vulnerable to Attacks 🛡️", "color": "#ff3344"}
        elif stats['health'] > 85 and stats['happiness'] > 80:
            return {"text": "Extremely Happy & Secure 🌟", "color": "#00ff66"}
        else:
            return {"text": "Stable & Operational 🟢", "color": "#00e5ff"}

    def handle_feed(self, cleared_mb):
        xp_gain = 25
        self.state['xp'] += xp_gain
        self.state['total_feeds'] += 1
        self._add_event("🍔 Storage Cleaned", f"Cleared {cleared_mb} MB of temp log bloat. +{xp_gain} XP!")
        self._save_state()
        return {"success": True, "xp_gained": xp_gain, "new_total_xp": self.state['xp']}

    def handle_play(self):
        xp_gain = 30
        self.state['xp'] += xp_gain
        self.state['total_plays'] += 1
        self._add_event("⚡ Process Optimized", f"Optimized CPU thread priority & idle routines. +{xp_gain} XP!")
        self._save_state()
        return {"success": True, "xp_gained": xp_gain, "new_total_xp": self.state['xp']}

    def handle_heal(self, fixed_count):
        xp_gain = 40
        self.state['xp'] += xp_gain
        self.state['total_heals'] += 1
        self._add_event("🛡️ Firewall Hardened", f"Patched {fixed_count} security ports & firewall rules. +{xp_gain} XP!")
        self._save_state()
        return {"success": True, "xp_gained": xp_gain, "new_total_xp": self.state['xp']}

    def attempt_evolution(self):
        curr_idx = self.state['stage']
        if curr_idx >= len(EVOLUTION_STAGES) - 1:
            return {"success": False, "message": "Pet is already at maximum Dragon Evolution stage! 🐉"}
        
        next_stage = EVOLUTION_STAGES[curr_idx + 1]
        if self.state['xp'] >= next_stage['min_xp']:
            self.state['stage'] += 1
            self._add_event("🐉 EVOLUTION UPGRADE", f"Pet evolved into {next_stage['name']} ({next_stage['emoji']})!")
            self._save_state()
            return {"success": True, "new_stage": next_stage}
        else:
            return {
                "success": False, 
                "message": f"Requires {next_stage['min_xp']} XP to evolve to {next_stage['name']}. Current XP: {self.state['xp']}"
            }

    def _add_event(self, title, desc):
        event = {
            "timestamp": time.strftime("%H:%M:%S"),
            "title": title,
            "desc": desc
        }
        self.events_history.insert(0, event)

    def get_event_history(self):
        if not self.events_history:
            return [
                {
                    "timestamp": time.strftime("%H:%M:%S"),
                    "title": "🚀 Platform Initialized",
                    "desc": "DOOM telemetry agent initialized on cloud VM."
                }
            ]
        return self.events_history
