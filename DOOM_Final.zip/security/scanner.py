import socket
import random

class SecurityScanner:
    def __init__(self):
        self.monitored_ports = [
            {"port": 22, "service": "SSH", "status": "OPEN", "risk": "Medium"},
            {"port": 80, "service": "HTTP Web", "status": "OPEN", "risk": "Low"},
            {"port": 443, "service": "HTTPS Secure", "status": "SECURE", "risk": "Safe"},
            {"port": 3306, "service": "MySQL DB", "status": "OPEN", "risk": "High"},
            {"port": 8080, "service": "Alt HTTP", "status": "EXPOSED", "risk": "High"}
        ]
        self.firewall_active = True
        self.iam_roles_hardened = False

    def get_report(self):
        open_high_risk = sum(1 for p in self.monitored_ports if p["status"] in ["EXPOSED", "OPEN"] and p["risk"] == "High")
        
        # Calculate security score (100 max)
        score = 100 - (open_high_risk * 25)
        if not self.firewall_active:
            score -= 20
        if not self.iam_roles_hardened:
            score -= 15

        score = max(20, min(100, score))

        return {
            "security_score": score,
            "firewall_active": self.firewall_active,
            "iam_hardened": self.iam_roles_hardened,
            "monitored_ports": self.monitored_ports,
            "high_risk_open_ports": open_high_risk,
            "status_text": "SHIELD HARDENED 🛡️" if score >= 85 else "VULNERABILITIES DETECTED ⚠️"
        }

    def fix_vulnerabilities(self):
        fixed_count = 0
        for p in self.monitored_ports:
            if p["status"] in ["EXPOSED", "OPEN"] and p["port"] in [3306, 8080]:
                p["status"] = "FILTERED & SECURED"
                fixed_count += 1
        
        self.firewall_active = True
        self.iam_roles_hardened = True

        return {
            "success": True,
            "fixed_count": max(1, fixed_count),
            "new_report": self.get_report()
        }
